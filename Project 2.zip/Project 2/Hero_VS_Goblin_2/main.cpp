/*
 * File:   main.cpp
 * author:Abanob Wahba
 * Created on June 3, 2017, 9:25 PM
 * Purpose: This game is a battle between 2 character hero and goblin you
 * choose hero or goblin and see successive rounds of fighting till health
 * of either Hero or Goblin becomes zero or less the computer will give random
 * skill levels and lives to fighters.
 */

//System Libraries
#include <vector>    //vector library
#include <iostream>  //Input - Output Library
#include <ctime>     //Time for rand
#include <cstdlib>   //Srand to set the seed
#include <fstream>   //File I/O
#include <sstream>   //sstream library
#include <iomanip>   //Format the output
#include <string>    //Strings
#include <cmath>     //Math functions
using namespace std; //Name-space under which system libraries exist

// constant globl variables
const int ARRAY_SIZE = 99;
//Function Prototypes
int linerSearch(string [], int, string);
int binarySearch(vector <string> &, string);// binary search - from material provided by instructor
void selectionSort(vector <string>&);// sort array
bool playGame();// check if user wants to play again
void writeData(int, string [], int [], float [], string ="players.txt");// store stats - write stats to file
int loadData(string, vector<string> &, string [][ARRAY_SIZE], string[],
    int [], float []);// load data from file into respective array and vector

//Execution begins here

int main(int argc, char** argv) {
    //Declare variables
    string userName="", userNm="";// This is a string variable
    bool play = true;
    int wins = 0, plays = 0, count=0;

    // initialize array to save previous winners
    string playerWins[ARRAY_SIZE][ARRAY_SIZE]; // 2D array

    // parallel array
    string dataName[ARRAY_SIZE];
    int dataNumberOfPlays[ARRAY_SIZE];
    float dataPercentageWin[ARRAY_SIZE];

    // store every player that has played the game
    vector<string> players;

    // load data
    count = loadData("players.txt", players, playerWins, dataName,
      dataNumberOfPlays, dataPercentageWin);

    // get the user's name
    cout<<"Hello there, i am Abanob, what's your name: ";
    getline(cin,userName);

    cout<<"\nEnjoy the game "<<userName<<"! :)"<<endl<<endl;


    while (play){
    //Declare and Initialize boolean variable isRunni to true for executing rounds
    int isRunni = true;//to give the result of the winer or loser
    bool is_hero,tieResu=false;// This is a boolean variable
    int input;//the user input
    bool tmpError = true;


    while (tmpError){
    // Get user choice 1 for  Hero , 0 for Goblin
   cout<<"Choose a Champion Enter 1 for Hero and 0 for Goblin "<<endl;
   cin>>input;
   //If user wants to be hero set is_hero to true
    if ( input == 1 )
    {
      is_hero = true;
      userNm="Hero";
      cout << "You have chosen " << userNm<< endl;
      tmpError = false;
   }
   //If user wants to be Goblin set is_hero to false
   else if(input==0)
    {
        is_hero=false;
        userNm="Goblin";
      cout << "You have chosen " <<userNm<< endl;
      tmpError = false;
    }
    //If user enters any other value, Display invalid input and exit returning 1
    else
    {
        cout << "Sorry! Invalid input" << endl;
    }
    }

    // Display Good luck Goblin or Good luck Hero based on initialize user choice
      switch(input)
      {//beginning of switch
         case 0: cout << "Good Luck, "<<userNm << endl; break;
         case 1: cout << "Good Luck, "<<userNm << endl; break;
      }//the end of the switch


   // Declare and initialize Hero skills and power parameters to zero
   int HeroHP = 0;//hero health
   int HeroDG = 0;//her damage and attack
   int HeroDF = 0;//hero defense and armor
   int HeroLF = 0; // hero life
   // Declare and initialize Goblin skills and power parameters to zero
   int GobliHP = 0;//Goblin health
   int GobliDG = 0;//Goblin damage and attack
   int GobliDF = 0;//Goblin defense and armor
   int GobliLF = 0; // Goblin life
   int matchRound = 1;

      //Seed the random function generation with current time
      srand(time(0));
      // Give goblin random health, attack, defence value
      int randHP = rand()%6;
      GobliHP = randHP;
      int randDG = rand()%6;
      GobliDG = randDG;
      int randDF = rand()%6;
      GobliDF = randDF;

    //Give the hero random health, attack, defence value
      int randHP2=rand()%6;
      HeroHP=randHP2;
      int randDG2=rand()%6;
      HeroDG = randDG2;
      int randDF2=rand()%6;
      HeroDF = randDF2;


   //Beginning of the while loop
   while(isRunni)
    {
       // Armor Zone : If hero and goblin attack parameter is less than zero set it to zero
       if (HeroDG < 0)
        {
          HeroDG = 0;
       }
       if (GobliDG < 0)
       {
          GobliDG = 0;
       }

       // Life steal Zone : Assign Hero and Goblin life random  value
       float HeroLe = 0.0f;//hero life steal
       float GobliLe = 0.0f;//goblin life steal
       HeroLe  = rand()%6;
       GobliLe = rand()%6;

        cout << "Match round: " << matchRound << endl;

       //Display fight started
       cout<<"Fight Started:" << endl;

       //Calculate Hero and Goblin health based on attack, defence, life steal and initial health parameters
       HeroHP = HeroHP - GobliDG + HeroDF + HeroLe;
       GobliHP = GobliHP - HeroDG + GobliDF + GobliLe;

       //Calculate Hero and Goblin defence parameter based on defence and attack parameter
       HeroDF = HeroDF - GobliDG;
       GobliDF= GobliDF- HeroDG;

       //If Hero defence after Fight is less than zero set it to zero
       if (HeroDF<0)
        HeroDF=0;

    	//If Goblin defence after fight is less than zero set it to zero
       if (GobliDF<0)
        GobliDF=0;

    //Display health, Armor, Attack and Life steal at the end of round

       cout<<"Hero health: "<<HeroHP<<", Armor: "<<HeroDF<<" Attack: "<< HeroDG
                                         <<" Life steal: "<<HeroLe<<" "<<endl;
       cout<<"Goblin health: "<<GobliHP<<", Armor: "<<GobliDF<<" Attack: "
                            << GobliDG <<" Life steal: "<<GobliLe<<" " <<endl<<endl;

       // If either of Goblin or Hero health is less than or equal to zero after the fight, end the loop by setting isRunni to false
       if (HeroHP <= 0 || GobliHP <= 0)
    {
    	isRunni = false;
    	//If both Goblin and Hero Health is less than or equal to zero after the fight, set TieResult variable as true
       if (HeroHP <= 0 && GobliHP <= 0)
       {
             cout << "Hero and Goblin are equally powerful" << endl;
             tieResu=true;
       }

       }
       matchRound++;//Increment the counter for number of rounds




       if(matchRound>=10)// If match does not finish by Tenth round decide the winner based on health parameter only
       {
           cout << "Last Round fight without weapons " << endl;
           if(HeroHP>GobliHP)
           {
               GobliHP =0;
               isRunni=false;
           }
           else if (GobliHP>HeroHP)
           {
               HeroHP=0;
               isRunni=false;
           }
           else
           {
               GobliHP =0;
               HeroHP=0;
               isRunni=false;
               tieResu=true;
           }

       }

   }//end of the while loop

   if ( GobliHP <= 0 && HeroHP >= 1)
    {
		ofstream myfile;// write out to result.txt the result of the match
		myfile.open ("result.txt");
		myfile << "Winner: Hero!\n";
		myfile.close();
		if (is_hero==true){//Using initial user choice display the result whether user won or lost
		cout << "You won!";
    wins += 1;
    }
		else
		cout << "You lost.";

   }
   else if ( HeroHP <= 0 && GobliHP >= 1 )
    {
      ofstream myfile;//write out to result.txt the result of the match
      myfile.open ("result.txt");
      myfile << "Winner: Goblin!\n";
      myfile.close();
      if (is_hero==false){//Using initial user choice display the result whether user won or lost
		    cout << "You won!";
        wins += 1;
      }
		else
		cout << "You lost.";
   }

   else if(tieResu==true)
   {
       ofstream myfile;//write out to result.txt the result of the match
      myfile.open ("result.txt");
      myfile << "Result is a tie\n";
      myfile.close();
      cout << "Result is a tie";

   }
   plays += 1;
   // check if user wants to play again
   play = playGame();
   cout<<endl<<endl<<endl;
    }
    // update stats arrays when the game is done

    // check if user has played before
    int tmpp;
    if (count > 0){
    selectionSort(players); // sort array
    int loc = binarySearch(players, userName);
    switch (loc)  {
      case -1:{
                players.push_back(userName);
                playerWins[count][0] = userName;
                playerWins[count][1] = to_string(wins);

                dataName[count] = userName;
                dataNumberOfPlays[count] = plays;
                tmpp = stoi(playerWins[count][1]);
                dataPercentageWin[count] = (float)tmpp / (float)dataNumberOfPlays[count];
                count += 1;
                break;
              }
      default:{
                tmpp = stoi(playerWins[loc][1]);
                tmpp += wins;
                playerWins[loc][1] = to_string(tmpp);

                dataName[loc] = userName;
                dataNumberOfPlays[loc] += plays;
                tmpp = stoi(playerWins[loc][1]);
                dataPercentageWin[loc] = tmpp / static_cast<float>(dataNumberOfPlays[loc]);
              }
    }
    }
    else{
      players.push_back(userName);
      playerWins[count][0] = userName;
      playerWins[count][1] = to_string(wins);

      dataName[count] = userName;
      dataNumberOfPlays[count] = plays;
      tmpp = stoi(playerWins[count][1]);
      cout<<plays<<" : "<<tmpp<<endl;
      dataPercentageWin[count] = (float)tmpp / (float)dataNumberOfPlays[count];
      cout<<dataPercentageWin[count]<<endl;
      count += 1;
    }
    // store stats - write stats to file
    writeData(count, dataName, dataNumberOfPlays,dataPercentageWin);

   return 0;
}

// linear search - from material provided by instructor
int linerSearch(string list[], int numElems, string value)
{
   int index = 0;      // Used as a subscript to search array
   int position = -1;  // To record position of search value
   bool found = false; // Flag to indicate if value was found

   while (index < numElems && !found)
   {
      if (list[index] == value) // If the value is found
      {
         found = true; // Set the flag
         position = index; // Record the value's subscript
      }
      index++; // Go to the next element
   }
return position; // Return the position, or -1
}

// binary search - from material provided by instructor
int binarySearch(vector <string>& array, string value)
{
   int first = 0,             // First array element
       last = array.size() - 1,       // Last array element
       middle,                // Mid point of search
       position = -1;         // Position of search value
   bool found = false;        // Flag

   while (!found && first <= last)
   {
      middle = (first + last) / 2;     // Calculate mid point
      if (array[middle] == value)      // If value is found at mid
      {
         found = true;
         position = middle;
      }
      else if (array[middle] > value)  // If value is in lower half
         last = middle - 1;
      else
         first = middle + 1;           // If value is in upper half
   }
   return position;
}

// selection sort - from material provided by instructor
void selectionSort(vector <string>& array)
{
  int startScan, minIndex;
  string minValue;
  for (startScan = 0; startScan < (array.size() - 1); startScan++)
  {
    minIndex = startScan;
    minValue = array[startScan];
    for(int index = startScan + 1; index < array.size(); index++)
    {
      if (array[index] < minValue)
      {
        minValue = array[index];
        minIndex = index;
      }
    }
    array[minIndex] = array[startScan];
    array[startScan] = minValue;
  }
}

// save the stats to file (players.txt)
void writeData(int count, string dataName[], int dataNumberOfPlays[], float dataPercentageWin[], string fName){
  ofstream myfile;//write out to result.txt the result of the match
  myfile.open (fName);

  for (int i=0; i<count; i++){
    myfile<<dataName[i]<<","<<dataNumberOfPlays[i]<<","
      <<dataNumberOfPlays[i]*dataPercentageWin[i]
        <<","<<dataPercentageWin[i]<<endl;
  }
  // close file
  myfile.close();
}
// load data from file into respective array and vector
int loadData(string fName, vector<string> & players, string playerWins[][ARRAY_SIZE], string dataName[],
    int dataNumberOfPlays[], float dataPercentageWin[]){
  // declarations
  int count=0;
  string playerName;
  int playerW;
  ifstream read (fName);

  for(string line; getline(read, line);)
  {
    stringstream stream(line);
    int tmpCount = 0, tmpN=0;
    float tmpNN=0;
    while(stream.good())
    {
      string substr;
      getline( stream, substr, ',' );

      // fill arrays up
      switch (tmpCount){
        case 0:{
          playerWins[count][0] = substr;
          dataName[count] = substr;
          players.push_back(substr);
          break;}
        case 1:{
          stringstream convert(substr);
          convert>>tmpN;
          dataNumberOfPlays[count] = tmpN;
          break;}
        case 2:{
          playerWins[count][1] = substr;
          break;}
        case 3:{
          stringstream convertc(substr);
          convertc>>tmpNN;
          dataPercentageWin[count] = tmpNN;
          break;}
      }
      tmpCount += 1;
      if (tmpCount == 4)
        tmpCount = 0;
    }
    count += 1;
  }
  return count;
}

//void saveData()

// returns true to keep the loop (game) running or
// vice versal
bool playGame(){
  // declare variables
  string answer;
  bool invalidInput = true, again = true;

  while (invalidInput){

  // prompt user if he/she wants to play again
  cout<<"\n\nDo you wish to play again (y or n): ";
  cin>>answer;

  if (answer == "Y" || answer == "y"){
    invalidInput = false;
  }
  else if (answer == "N" || answer == "n"){
    again = false;
    invalidInput = false;
  }
  else{
    cout<<"\nInvalid input! (y or n)"<<endl;
  }
  }
  return again;
}
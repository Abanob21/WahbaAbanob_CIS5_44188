/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 14, 2017, 10:32 AM
 * Purpose:  let the user enter a charge account number the program should
 * check if the number is correct.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
void linerS(int [],int);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int num=18;
    int arraySz=18;
    int array[arraySz]={5658845,8080152,1005231,4520125,4562555,6545231,7895122
            ,5552012,3852085,8777541,5050552,7576651,8451277,7825877,7881200
            ,1302850,125055,4581002};
    linerS(array,num);
}
void linerS(int array[],int num)
{
    int chargeN;
    bool found = false;
    cout<<"Enter the account c89/harge number"<<endl;
    cin>>chargeN;
    for(int i=0;i<num;i++)
    {
        if(array[i] == chargeN)
        {
            found-true;
            break;
        }
        if(found)
        {
            cout<<"The number  is in valid"<<endl;
        }
        else
        {
            cout<<"Number is in valid"<<endl;
        }
    }
    
}


/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on April 13, 2017, 7:32 PM
 * Purpose: tow identical array of just eight integers
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
void bubble(int arr[],int);
void select(int arr[],int);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int array1[8]={5,1,4,6,2,8,2,7};
    int array2[8]={5,1,4,6,2,8,2,7};
    int i;//loop variable
    for(i=0;i<8;i++)
        cout<<" "<<array1[i];
    cout<<endl;
    bubble(array1,8);
    cout<<"contents of the second array"<<endl;
    for(i=0;i<8;i++)
        cout<<" "<<array2[i];
    cout<<endl;
    select(array2,8);
}
void bubble(int array[],int size)
{
    bool swap;
    int temp;
    cout<<"bubble sort"<<endl;
    do
    {
        swap=false;
        for(int count=0;count<(size-1);count++)
        {
            if(array[count]>array[count+1])
            {
                temp=array[count];
                array[count]=array[count+1];
                array[count+1]=temp;
                swap=true;
            }
        }
        for(int i=0;i<size;i++)
            cout<<array[i]<<" ";
        cout<<endl;
        
    }while (swap);
}
void select(int array[],int size)
{
    int startSc,minIndex,minVal;
    cout<<"selection sort"<<endl;
    for(startSc=0;startSc<(size-1);startSc++)
    {
        minIndex=startSc;
        minVal=array[startSc];
        for(int index=startSc+1;index<size;index++)
        {
            if(array[index]<minVal)
            {
                minVal=array[index];
                minIndex=index;
            }
        }
        array[minIndex]=array[startSc];
        array[startSc]=minVal;
        for(int i=0;i<size;i++)
            cout<<array[i]<<" ";
        cout<<endl;
    }
}
/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on April 14, 2017, 7:32 PM
 * Purpose:  a lottery ticket buyer purchases 10 tickets a week always plays
 * the same 5-10 digit lucky combinations.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//defining size with 10
#define SIZE 10 
//Function Prototypes
bool serchW(int[],int,int);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int winNum[10]={13579,26791,26792,33445,55555,62483,77777,79422,85647,93121};
    int playNum;
    cout<<"player enter your number: ";
    cin>>playNum;
    //calling search function
    bool result=serchW(winNum,SIZE,playNum);
    //result true or not
    if(result)
        cout<<"one of the winning number is yours"<<endl;
    else
        cout<<"you did not win"<<endl;
}
bool serchW(int winNum[],int size,int playNum)
{
    bool found=false;
    int index=0;
    while(index<size&!found)
    {
        if(winNum[index]==playNum)
            found=true;
        index++;
        
    }
    return found;
}

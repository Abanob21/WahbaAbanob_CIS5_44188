/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 13, 2017, 10:32 AM
 * Purpose:  display the largest and the smallest value
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int size=10;
    int small,large;
    int number[size];
    //input elements of the array
    cout<<"Enter the value of array 10: "<<endl;
    for(int i=0;i<size;i++)
    {
        cin>>number[i];
    }
    //assigning starting element to small and large
    small=number[0];
    large=number[0];
    //logic to find largest and smallest
    for(int j=0;j<size;j++)
    {
        if(number[j]>large)
            large=number[j];
        if(number[j]<small)
            small=number[j];
    }
    //Initialize variables
    
    //Input data
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"the smallest value is: "<<small<<endl;
    cout<<"The largest value is: "<<large<<endl;
    //Exit stage right!
    return 0;
}


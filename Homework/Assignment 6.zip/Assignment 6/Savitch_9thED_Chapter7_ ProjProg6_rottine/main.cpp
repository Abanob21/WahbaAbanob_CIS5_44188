/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on may 13, 2017, 11:32 PM
 * Purpose: the selection sort
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function definitions
void swapVl(int & variabl1,int& variabl2)
{
    int temp;
    temp=variabl1;
    variabl1=variabl2;
    variabl2=temp;
}
void sort(int arr[],int length)
{
    int i,j;
    for(i=1;i<length;i++)
    {
        j=i;
        while(j>0 && arr[j-1]>arr[j])
        {
            swapVl(arr[j],arr[j-1]);
            j--;
        }
    }
}

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int i;
    int a[10]={9,8,7,6,5,1,2,3,0,4};
    cout<<"unsorted integers:\n";
    for(i=0;i<10;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    sort(a,10);
    cout<<"in sorted order the integers are:\n";
    for(i=0;i<10;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    //Initialize variables
    
    //Input data
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}


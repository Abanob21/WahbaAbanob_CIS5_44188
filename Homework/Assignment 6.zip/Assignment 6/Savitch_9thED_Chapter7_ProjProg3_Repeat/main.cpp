/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on April 14, 2017, 9:32 PM
 * Purpose:  delete all the repeated letters from the array
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
void deleteR(char a[],int & position);
bool findCr(char target,char a[] ,int size);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    char a[81];
    int size=53;
    cout<<"before : size = "<<size<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<a[i];
    }
    cout<<endl;
    //function call
    deleteR(a,size);
    cout<<"After : size= "<<size<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<a[i];
    }
    cout<<endl;
    return 0;
}
bool findCr(char target,char a[], int size)
{
    for(int i=0;i<size;i++)
{
    if(a[i]==target)
        return true;
}
    return false;
}
void deleteR(char a[],int& position)
{
    int newSize=0;
    for(int i=0;i<position;i++)
    {
        if(!findCr(a[i],a,newSize))
        {
            a[newSize]=a[i];
            newSize++;
        }
    }
    position=newSize;
}


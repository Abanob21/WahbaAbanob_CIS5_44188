/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on April 14, 2017, 3:32 PM
 * Purpose:  a lottery ticket buyer purchases 10 tickets a week always plays
 * the same 5-10 digit lucky combinations second version search using binary
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//defining size with 10
#define SIZE 10 
//Function Prototypes
bool searchW(int[],int,int);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int winNum[10]={13579,26791,26792,33445,55555,62483,77777,79422,85647,93121};
    int playNum;
    cout<<"player enter your number: ";
    cin>>playNum;
    //calling search function
    bool result=searchW(winNum,SIZE,playNum);
    //result true or not
    if(result)
        cout<<"one of the winning number is yours"<<endl;
    else
        cout<<"you did not win"<<endl;
}
bool searchW(int winNum[],int size,int playNum)
{
    int     first=0,
            last=size-1,
            middle;
    bool found=false;
    while(!found && first<=last)
    {
        middle=(first+last)/2;
        if(winNum[middle]==playNum)
            found=true;
        else if(winNum[middle]>playNum)
            last=middle-1;
        else
            first=middle+1;
        
    }
    return found;
}

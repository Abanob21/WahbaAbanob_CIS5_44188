/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 13, 2017, 11:32 AM
 * Purpose:  the program should read the contents of the file into the array.
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <fstream>
#include <string>
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int array[30],counter,num,total;
    int small,large;
    ifstream infile;
    //input file name
    //cout<<"Enter file name";
    //cin>>filename;
    //put the number in the file
    infile.open("numbers.txt");
    infile>>num;
    counter=0;
    while(infile)
    {
        array[counter]=num;
        infile>>num;
        counter++;
    }
    small=array[0];
    large=array[0];
    total=0;
    //logic to find largest and smallest
   for(int j=0;j<counter;j++)
    {
        if(array[j]>large)
            large=array[j];
        if(array[j]<small)
            small=array[j];
        total=total+array[j];
    }
    //Initialize variables
    
    //Input data
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"The smallest value is: "<<small<<endl;
    cout<<"The largest value is: "<<large<<endl;
    cout<<"total of number in array: "<<total<<endl;
    cout<<"average of numbers in array: "<<total/counter<<endl;
    infile.close();
    //Exit stage right!
    return 0;
}


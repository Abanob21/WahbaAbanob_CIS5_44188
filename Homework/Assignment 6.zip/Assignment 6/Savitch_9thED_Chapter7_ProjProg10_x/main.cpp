/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on April 14, 2017, 4:32 PM
 * Purpose:  play Tic-Tac-Toe
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
void showBd(char board[]);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    char board[9];
    int i;
    int numMove = 0;
    char whoseT = 'X';
    int move;
    //Initialize variables
  for (i=0;i<9;i++)
  {
      board[i] = '1'+i;
  }
    //get move
    while(numMove < 9)
    {
        showBd(board);
        cout<<"Enter move: "<<endl;
        cin>>move;
        if((move<1)||(move>9))
            cout<<"invalid move , try againe"<<endl;
        else
        {move--;
                if((board[move]=='X') || (board[move]=='O'))
                    cout<<"That space is taken"<<endl;
                else
                {
                    board[move] = whoseT;
                    if(whoseT == 'X')
                        whoseT = 'O';
                    else
                        whoseT = 'X';
                                numMove++;
                }
        }
    }
    showBd(board);
    cout<<endl<<"Game over"<<endl;
    return 0;
}
void showBd(char board[])
{
    cout<<endl;
    for(int i=0;i<9;i++)
    {
        cout<<board[i]<<" ";
        if(((i+1) % 3)==0)cout<<endl;
    }
    cout<<endl;
}

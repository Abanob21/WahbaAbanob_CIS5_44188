/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on May 3, 2017, 6:32 PM
 * Purpose:  determine the distance the object falls in specific time period.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
float fallDis(int);//falling distance
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float distanc;//distance
    int time;
    //loop to repeat time
    for(time=1; time<=10;time++)
    {
        distanc=fallDis(time);
        cout<<"distance at time interval "<<time<<" in meter is: "
                <<distanc<<endl;
    }
}
float fallDis(int time)
{
    float distanc,g=9.8;
    distanc=static_cast<float>(0.5*g*time*time);
    return distanc;
}


/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 2, 2017,9:12 AM
 * Purpose: Standard and average deviation of four scores.
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>      //Math functions
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
float average(float s1,float s2,float s3,float s4);
float deviat(float s1,float s2,float s3,float s4,float average,int n);//standard deviation
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float s1,s2,s3,s4;//scores
    float avg,sdeviat;//average deviation
    char choice;
    //Initialize variables
    
    //Input data
    do
    {
        cout<<"Enter the value of s1: ";
        cin>>s1;
        cout<<"Enter the value of s2: ";
        cin>>s2;
        cout<<"Enter the value of s3: ";
        cin>>s3;
        cout<<"Enter the value of s4: ";
        cin>>s4;
        avg=average(s1,s2,s3,s4);
        //function call
        sdeviat=deviat(s1,s2,s3,s4,avg,4);
    //output
        cout<<"standard deviation "<<sdeviat<<endl;
        cout<<"Enter 'y' or 'Y' to repeat";
        cin>>choice;
    }while (choice =='y'||choice=='Y');
    //function definitions
}
    float average(float s1,float s2,float s3,float s4)
    {    
        return (s1+s2+s3+s4)/4;
    //end average
    }
        float deviat(float s1,float s2,float s3,float s4,float mean,int n)
        {
        float sd;
        sd=(pow((s1-mean),2)+pow((s2-mean),2)+
                pow((s3-mean),2)+pow((s4-mean),2))/n;
        sd=sqrt(sd);
        return sd;
        }


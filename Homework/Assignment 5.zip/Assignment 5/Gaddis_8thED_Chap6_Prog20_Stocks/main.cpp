/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 3, 2017, 8:32 PM
 * Purpose: the profit from sale stock .
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>     //Math function
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
float stockPt(float,float,float,float,float);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float   NS,//Number of shares
            PP,//price of each share
            PC,//purchase commision
            SC,//sale commision
            SP,//price of share
            profit;//the profit
    //input
    cout<<"Enter the number of shares: ";
    cin>>NS;
    cout<<"Enter the price of each shares: ";
    cin>>PP;
    cout<<"Enter the purchase commision: ";
    cin>>PC;
    cout<<"Enter the price per shares: ";
    cin>>SP;
    cout<<"Enter sale commision: ";
    cin>>SC;
    //function
    profit=stockPt(NS,PP,PC,SC,SP);
    //Profit or loss
    if(profit<0)
        cout<<"loss on the sale of stock is: "<<abs(profit)<<endl;
    else
        cout<<"profit on the sale of stock is: "<<profit<<endl;
}
float stockPt(float NS,float PP,float PC,float SP,float SC)
{
    float profit;
    profit=((NS*SP)-SC)-((NS*PP)+PC);
    return profit;
    
}
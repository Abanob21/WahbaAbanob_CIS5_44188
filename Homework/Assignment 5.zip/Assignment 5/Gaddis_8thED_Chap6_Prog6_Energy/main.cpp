/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 3, 2017, 7:32 PM
 * Purpose: determine a moving object kinetic energy
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
float kEnergy(float,float);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float mass,velocit,KE;//velocity and kinetic energy
    //input
    cout<<"Enter mass of body: ";
    cin>>mass;
    cout<<"Enter velocity: ";
    cin>>velocit;
    //calculate distance
KE=kEnergy(mass,velocit);
cout<<"kinetic energy: "<<KE<<endl;
}
//function
float kEnergy(float mass,float velocit)
{
    float KE;
    KE=(0.5*mass*velocit*velocit);
    return KE;
}

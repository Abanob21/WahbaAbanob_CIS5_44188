/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on May 3, 2017, 11:32 AM
 * Purpose:  to display the retail cost of item .
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
float calculat(float cost,float perce);//calculate retail

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
float wcost,retail,percent;
//input
cout<<"Enter whole sale cost: ";
cin>>wcost;
cout<<"Enter marked percentage: ";
cin>>percent;
//function call
retail=calculat(wcost,percent);
//output
cout<<"retail cost of item is: "<<retail<<endl;
}//end main
//function definition
float calculat(float cost,float perc)
{
    float retail;
    retail=cost+((cost*perc)/100);
    return retail;
}


/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on May 3, 2017, 8:00 AM
 * Purpose:  read the length in feet and inches and output the length in meters
 * and centimeters
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>     //The math fucntions
#include <string>    // strings
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
void input(float &feet,float &inches);
void calcula(float feet,float inches,float &meters,float &cm);//void calculate
void disPy(float meters,float cm,float feet,float inches);
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float feet,inches,meters,cm;
    char answer;
    do
    {
        cout<<"feet and inches to meters and centimeters"<<endl;
        //function call to input
        input(feet,inches);
        //function call
        calcula(feet,inches,meters,cm);
        //function call for display
        disPy(meters,cm,feet,inches);
        //inputing choice
        cout<<"to repeat the calculation enter 'y' or 'Y' "<<endl;
        cin>>answer;
    }while (answer == 'y'||answer == 'Y');
    return 0;
}

void input(float &feet,float &inches)
{
    //input
    cout<<"feet: ";
    cin>>feet;
    cout<<"Inches: ";
    cin>>inches;
}
void calcula(float feet,float inches,float &meters,float &cm)
{
    //convert inches and feet to meters
    meters=feet*0.3048 + (inches*0.0254);
    //convert inches and feet to centimeters
    cm=(feet*30.48+inches*2.54);
}
void disPy(float meters,float cm,float feet,float inches)
{
    cout<<"There are "<<meters<<" meters "<<cm<<" centimeters in "<<feet<<" feet "
            <<inches<<" inches "<<endl;
}
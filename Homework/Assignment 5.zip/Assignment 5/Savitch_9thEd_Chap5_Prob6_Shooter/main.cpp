/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 3, 2017, 10:40 AM
 * Purpose:  Shooter Program
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cstdlib>   //Random number generator
#include <ctime>     //Time to set the random number seed
#include <cmath>     //Math Library
#include <iomanip>   //Format output
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const int MAXRND=pow(2,31)-1; //Max random number

//Function Prototypes
//Probability -> [0,1]
float rndProb(){
    return static_cast<float>(rand())/MAXRND;
}

void heading(){
    cout<<"Table of shooting results"<<endl;
    cout<<"A -> Alive, D -> Dead"<<endl;
    cout<<"Aaron Bob Charles  Turn"<<endl;
}
void results(bool a,bool b,bool c,char t){
    cout<<"  "<<(a?'A':'D');
    cout<<"    "<<(b?'A':'D');
    cout<<"     "<<(c?'A':'D');
    cout<<"     ";
    if(t==0)cout<<"Aaron"<<endl;
    if(t==1)cout<<"Bob"<<endl;
    if(t==2)cout<<"Charles"<<endl;
}

//Execution begins here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare variables
    float pHitA=1.0f/3;//Probability of hit for Aaron
    float pHitB=1.0f/2;//Probability of hit for Bob
    float pHitC=1.0f;  //Probability of hit for Charlie
    bool aliveA=true;  //Aaron is alive
    bool aliveB=true;  //Bob is alive
    bool aliveC=true;  //Charles is alive
    char turn=0;
    
    
    //Map inputs to outputs or process the data
    heading();
    do{
        if(aliveA&&turn==0){
            if(aliveC){
                if(pHitA>=rndProb())aliveC=false;
            }else{
                if(pHitA>=rndProb())aliveB=false;
            }
        }else if(aliveB&&turn==1){
            if(aliveC){
                if(pHitB>=rndProb())aliveC=false;
            }else{
                if(pHitB>=rndProb())aliveA=false;
            }
        }else if(aliveC&&turn==2){
            if(aliveB){
                aliveB=false;
            }else{
                aliveA=false;
            }
        }
        results(aliveA,aliveB,aliveC,turn);
        turn++;
        turn%=3;
    }while((aliveA+aliveB+aliveC)>1);
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}
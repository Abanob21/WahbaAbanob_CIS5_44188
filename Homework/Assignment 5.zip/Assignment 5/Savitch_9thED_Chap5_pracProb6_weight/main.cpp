/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on May 3, 2017, 1:00 PM
 * Purpose:  read the length in feet and inches and output the length in meters
 * and centimeters
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>     //The math fucntions
#include <string>    // strings
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
void input(float &pounds,float &ounce);
void convert(float &pounds,float &ounce,float kilo,float grams);//void calculate
void disPy(float pounds,float ounce,float kilo,float grams);//void display
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float pounds,ounce,kilo,grams;
    char answer;
    do
    {
        cout<<"convert grams and kilos to pounds and ounce"<<endl;
        //function call to input
        input(kilo,grams);
        //function call
        convert(pounds,ounce,kilo,grams);
        //function call for display
        disPy(pounds,ounce,kilo,grams);
        //inputing choice
        cout<<"to repeat the calculation enter 'y' or 'Y' "<<endl;
        cin>>answer;
    }while (answer == 'y'||answer == 'Y');
    return 0;
}

void input(float &kilo,float &grams)
{
    //input
    cout<<"kilograms: ";
    cin>>kilo;
    cout<<"Grams : ";
    cin>>grams;
}
void convert(float &pounds,float &ounce,float kilo,float grams)
{
    //convert kilos and grams to pounds
    pounds  = (kilo*2.2046)+((grams/16)*2.2046);
    ounce=16*pounds;
}
void disPy(float pounds,float ounce,float kilo,float grams)
{
    cout<<"There are "<<pounds<<" pounds and "<<ounce<<" ounce in "<<kilo<<" kilograms "
            <<grams<<" grams "<<endl;
}
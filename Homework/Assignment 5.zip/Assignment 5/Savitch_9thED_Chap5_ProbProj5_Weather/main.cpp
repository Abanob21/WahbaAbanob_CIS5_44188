/* 
 * File:   main.cpp
 * Author: Abanob Wahba
 * Created on May 3, 2017, 10:00 AM
 * Purpose: to calculate the wind chill factor in the weather
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>     //The math fucnrion
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
float function(float windSd,float temp,float windCh);//wind speed, wind temperature and windchillindex
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float windSd,temp,windCh=0;//wind speed, wind temperature and windchillindex
    //input
    cout<<"enter the speed in /sec\n";
    cin>>windSd;
    cout<<"Enter the temperature in degree celsius \n";
    cin>>temp;
    windCh = function(windSd,temp,windCh);
    cout<<windCh;
}
float function(float windSd,float temp, float windCh)
{
    return windCh = (13.12+0.6215*temp-11.37*pow(windSd,0.16)+0.3965*temp*pow(windSd,0.016));
}
